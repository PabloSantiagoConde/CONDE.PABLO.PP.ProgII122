/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Exceptions.ExpedienteDuplicadoException;
import Exceptions.ExpedienteNuloException;
import Enum.NivelSecreto;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Voolkia
 */
public class ArchivoSecreto {

    private String nombre;
    private List<Expediente> expedientes = new ArrayList<>();

    public ArchivoSecreto(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void agregarExpediente(Expediente e) {
        validarExpediente(e);
        expedientes.add(e);
    }

    public List<Expediente> obtenerExpedientes() {
        return expedientes;
    }

    public List<Expediente> filtrarPorNivel(NivelSecreto nivel) {
        List<Expediente> resultado = new ArrayList<>();
        for (Expediente a : expedientes) {
            if (a.getNivelSecreto() == nivel) {
                resultado.add(a);
            }
        }
        return resultado;
    }

    //Se procede a realizar los metodos auxiliares para agregarExpediente
    private void validarExpediente(Expediente e) {
        if (e == null) {
            throw new ExpedienteNuloException("El expediente no puede ser nulo");
        }
        for (Expediente expediente : this.expedientes) {
            if (expediente.equals(e)) {
                throw new ExpedienteDuplicadoException(
                        "Ya existe un expediente con codigo '" + e.getCodigo()
                        + "' y agente '" + e.getAgente() + "'.");
            }
        }
    }

}
