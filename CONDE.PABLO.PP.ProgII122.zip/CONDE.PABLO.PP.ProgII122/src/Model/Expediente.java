/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;
import Enum.NivelSecreto;
import java.util.Objects;
/*
Clase abstracta de los expedientes
 */
public abstract class Expediente {
    private String codigo;
    private String agente;
    private NivelSecreto nivelSecreto;
    
    public Expediente(String codigo,String agente,NivelSecreto nivelSecreto){
        this.codigo=codigo;
        this.agente=agente;
        this.nivelSecreto=nivelSecreto;
    }
    
    public String getCodigo(){return codigo;}
    public String getAgente(){return agente;}
    public NivelSecreto getNivelSecreto(){return nivelSecreto;}
    
    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof Expediente a)) return false;
        return this.codigo.equals(a.codigo) && this.agente.equals(a.agente);
    }

    @Override
    public int hashCode() {
        return Objects.hash(codigo, agente);
    }
    
    @Override
    public String toString(){
        return "[codigo=" + codigo + ", agente=" + agente + ", nivelSecreto=" + nivelSecreto;
    }
}
