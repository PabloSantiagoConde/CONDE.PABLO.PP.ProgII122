/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;
import Enum.NivelSecreto;
import Interfaces.Analizable;

/**
 *
 * @author Voolkia
 */
public class AvistamientoAereo extends Expediente implements Analizable{
    private String ubicacion;
    
    public AvistamientoAereo (String codigo,String agente,NivelSecreto nivelSecreto, String ubicacion){
        super(codigo,agente,nivelSecreto);
        this.ubicacion=ubicacion;
    }
    
    public String getUbicacion(){return ubicacion;}
    
    @Override
    public void analizar(){
        System.out.println("Se analizo el avistamiento aereo: " + getCodigo());
    }
    
    @Override
    public String toString(){
        return "AvistamientoAereo " + super.toString() + ", ubicacion=" + ubicacion + "]";
    }
}
