/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;
import Enum.NivelSecreto;
import Interfaces.Reportable;

/**
 *
 * @author Voolkia
 */
public class TestimonioClasificado extends Expediente implements Reportable{
    private String nombreClaveTestigo ;
    
    public TestimonioClasificado (String codigo,String agente,NivelSecreto nivelSecreto, String nombreClaveTestigo ){
        super(codigo,agente,nivelSecreto);
        this.nombreClaveTestigo=nombreClaveTestigo ;
    }
    
    public String getNombreClaveTestigo (){return nombreClaveTestigo ;}
    
    
    @Override
    public void reportar(){
        System.out.println("Reporte de testimonio clasificado: " + getCodigo() + ". Nombre clave del testigo: "+nombreClaveTestigo  +".");
    }
    
    @Override
    public String toString(){
        return "TestimonioClasificado " + super.toString() + ", nombreClaveTestigo=" + nombreClaveTestigo  + "]";
    }
}
