/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;
import Enum.NivelSecreto;
import Interfaces.Analizable;
import Interfaces.Reportable;

/**
 *
 * @author Voolkia
 */
public class RegistroRadar extends Expediente implements Analizable,Reportable{
    private int altitudDetectada;
    
    public RegistroRadar (String codigo,String agente,NivelSecreto nivelSecreto,int altitudDetectada){
        super(codigo,agente,nivelSecreto);
        this.altitudDetectada=altitudDetectada;
    }
    
    public int getAltitudDetectada(){return altitudDetectada;}
    
    @Override
    public void analizar(){
        System.out.println("Se analizo el registro de radar: " + getCodigo());
    }
    
    @Override
    public void reportar(){
        System.out.println("Reporte de radar: " + getCodigo() + ". Altitud detectada: "+altitudDetectada +" metros.");
    }
    
    @Override
    public String toString(){
        return "RegistroRadar " + super.toString() + ", altitudDetectada=" + altitudDetectada + "]";
    }
}