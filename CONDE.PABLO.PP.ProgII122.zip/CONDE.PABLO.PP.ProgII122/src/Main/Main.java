/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;

import Model.ArchivoSecreto;
import Model.AvistamientoAereo;
import Model.Expediente;
import Model.TestimonioClasificado;
import Exceptions.ExpedienteDuplicadoException;
import Enum.NivelSecreto;
import Model.RegistroRadar;
import Interfaces.Analizable;
import Interfaces.Reportable;
import java.util.List;


  
public class Main{
    public static void main(String[] args) {
        ArchivoSecreto archivo = new ArchivoSecreto("Boveda 51");
        try {
            archivo.agregarExpediente(
                    new AvistamientoAereo("UAP-001", "Agente Fox", NivelSecreto.ALTO,
                            "Desierto de Nevada")
            );
            archivo.agregarExpediente(
                    new RegistroRadar("RAD-777", "Agente Dana", NivelSecreto.MEDIO,
                            12500)
            );
            archivo.agregarExpediente(
                    new TestimonioClasificado("TEST-404", "Agente Skinner",
                            NivelSecreto.BAJO, "Testigo Orion")
            );
            archivo.agregarExpediente(
                    new RegistroRadar("RAD-999", "Agente Fox", NivelSecreto.ALTO,
                            18300)
            );
            archivo.agregarExpediente(
                    new AvistamientoAereo("UAP-001", "Agente Fox", NivelSecreto.MEDIO,
                            "Roswell")
            );
        } catch (ExpedienteDuplicadoException e) {
            System.out.println("No se pudo agregar el expediente: " + e.getMessage());
        }
        System.out.println("Expedientes registrados:");
        mostrarExpedientes(archivo.obtenerExpedientes());
        System.out.println();
        System.out.println("Expedientes analizables:");
        analizarExpedientes(archivo.obtenerExpedientes());
        System.out.println();
        System.out.println("Reportes generados:");
        generarReportes(archivo.obtenerExpedientes());
        System.out.println();
        System.out.println("Expedientes de nivel ALTO:");
        mostrarExpedientes(archivo.filtrarPorNivel(NivelSecreto.ALTO));
    }

    private static void mostrarExpedientes(List<Expediente> expedientes) {
        for (Expediente e : expedientes) {
            System.out.println(e.toString());
        }
    }


    private static void analizarExpedientes(List<Expediente> expedientes) {
        for (Expediente e : expedientes) {
            if (e instanceof Analizable a) {
                a.analizar();
            } else {
                System.out.println("El expediente '" + e.getCodigo() + "' no puede analizarse.");
            }
        }
    }
    private static void generarReportes(List<Expediente> expedientes) {
        for (Expediente e : expedientes) {
            if (e instanceof Reportable r) {
                r.reportar();
            } else {
                System.out.println("El expediente '" + e.getCodigo() + "' no genera reporte.");
            }
        }
    }
}